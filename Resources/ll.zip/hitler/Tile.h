#include <Windows.h>
#include <SFML/Graphics.hpp>
#include <iostream>
#include <map>
#include <utility>
#include <string>
#include <vector>

#include "Input.h"
using namespace std;
using namespace sf;

void TilePeli();
void Initialize();
void CreateSprite(string name, string path);




